import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Questions } from 'src/app/qaportal/qaportal.component';
import { UserService } from './user-service.service';

@Injectable({
  providedIn: 'root'
})
export class QAService {

  constructor(
    private http : HttpClient,
    private userService : UserService
  ) { }

  getAllQuestions() {
    let token = sessionStorage.getItem('authToken')
    let jwtTokenStr = 'Bearer ' + token
    const headers = new HttpHeaders().set("Authorization", jwtTokenStr)
    return this.http.get<Questions[]>('http://localhost:8081/getallquestions', {headers})
  }

  postQuestion(question : Questions) {
    let token = sessionStorage.getItem('authToken')
    let jwtTokenStr = 'Bearer ' + token
    const headers = new HttpHeaders().set("Authorization", jwtTokenStr)
    return this.http.post('http://localhost:8081/postquestion', question, {headers})
  }

}

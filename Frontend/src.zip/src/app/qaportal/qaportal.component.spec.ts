import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QaportalComponent } from './qaportal.component';

describe('QaportalComponent', () => {
  let component: QaportalComponent;
  let fixture: ComponentFixture<QaportalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QaportalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QaportalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

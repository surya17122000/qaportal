import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Questions } from '../qaportal/qaportal.component';
import { QAService } from '../service/data/qa.service';

@Component({
  selector: 'app-post-question',
  templateUrl: './post-question.component.html',
  styleUrls: ['./post-question.component.css']
})
export class PostQuestionComponent implements OnInit {

  question!: Questions

  isPosted = false

  constructor(
    private qaService : QAService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.question = new Questions(0, '', '', 0, '', '')
  } 

  handlePostQuestion() {
    this.qaService.postQuestion(this.question).subscribe()
    this.isPosted = true
  }

}

package com.qaportal.questions.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qaportal.questions.entity.QuestionEntity;
import com.qaportal.questions.feign.UserAuthProxy;
import com.qaportal.questions.repository.QuestionRepository;

@Service
public class QuestionService {

	@Autowired
	private QuestionRepository questionRepository;
	
	@Autowired
	private UserAuthProxy userAuthProxy;

	public List<QuestionEntity> getallQuestions() {
		return questionRepository.findAll();
	}

	public void addQuestion(QuestionEntity questionEntity, String username) {
		int userid = userAuthProxy.getUserId(username);
		questionEntity.setUserid(userid);
		questionRepository.save(questionEntity);
	}

	public boolean existsByQuestionId(int questionid) {
		return questionRepository.existsById(questionid);
	}

	public String getUsernameFromToken(String headertoken) {
		
		try {
			String username = userAuthProxy.getTokenUsername(headertoken);
			return username;
		} catch (Exception e) {
			return null;
		}
		
	}

}

package com.qaportal.user.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.qaportal.user.entity.UserEntity;
import com.qaportal.user.entity.UserLoginEntity;
import com.qaportal.user.service.AuthenticateService;
import com.qaportal.user.service.UserService;

@RestController
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private AuthenticateService authService;

	Logger log = LoggerFactory.getLogger(UserController.class);

	@PostMapping("/registeruser")
	public ResponseEntity<Object> registerUser(@RequestBody UserEntity userentity) {

		if (userService.existsByemailid(userentity.getEmailid()))
			return ResponseEntity.status(HttpStatus.CONFLICT).body("Email already registered!");

		boolean isSuccessful = userService.addUser(userentity);

		if (isSuccessful)
			return ResponseEntity.status(HttpStatus.CREATED).body("User registered");
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid Password");
	}

	@GetMapping("/getallusers")
	public ResponseEntity<Object> getAllUsers(@RequestHeader(value = "Authorization") String token) {

		String username = authService.getUsernameFromToken(token);
		if (username == null)
			return new ResponseEntity<Object>("Invalid/Expired Token", HttpStatus.BAD_REQUEST);
		List<UserEntity> userEntities = userService.retriveAllUsers(username);
		return new ResponseEntity<Object>(userEntities, HttpStatus.OK);

	}

	@PostMapping("/authenticate")
	public ResponseEntity<Object> generateToken(@RequestBody UserLoginEntity userLoginEntity) {

		String response = authService.authenticate(userLoginEntity);
		if (response.equals("Invalid Password"))
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		return new ResponseEntity<Object>(response, HttpStatus.OK);

	}

	@GetMapping("/tokenusername")
	public String getTokenUsername(@RequestHeader(value = "Authorization") String token) {

		String username = authService.getUsernameFromToken(token);
		return username;

	}

	@GetMapping("/getuserid/{username}")
	public int getUserId(@PathVariable String username) {
		return userService.findByemailid(username).getUserid();
	}

}
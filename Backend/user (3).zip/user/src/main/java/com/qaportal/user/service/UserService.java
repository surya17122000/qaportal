package com.qaportal.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import com.qaportal.user.entity.UserEntity;
import com.qaportal.user.exception.NoRecordFoundException;
import com.qaportal.user.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	String password_regex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";

	public Boolean existsByemailid(String emailid) {

		return userRepository.existsByemailid(emailid);

	}

	public boolean addUser(UserEntity userentity) {

		String user_entered_password = userentity.getPassword();
		if (user_entered_password.matches(password_regex)) {
			userentity.setPassword(hashPassword(user_entered_password));
		} else {
			return false;
		}
		userRepository.save(userentity);
		return true;

	}

	public List<UserEntity> retriveAllUsers(String username) {

		return userRepository.findAll();

	}

	public UserEntity findByemailid(String emailid) {

		UserEntity user = userRepository.findByemailid(emailid);
		if(user == null)
			throw new NoRecordFoundException(emailid);
		return user;

	}

	public UserEntity getPasswordByUsername(String emailid) {
		UserEntity user = userRepository.findByemailid(emailid);
		if(user == null)
			throw new NoRecordFoundException(emailid);
		return user;
	}

	public String hashPassword(String plainTextPassword) {
		return BCrypt.hashpw(plainTextPassword, BCrypt.gensalt());
	}

	public boolean checkPass(String plainPassword, String hashedPassword) {
		return BCrypt.checkpw(plainPassword, hashedPassword);
	}

}

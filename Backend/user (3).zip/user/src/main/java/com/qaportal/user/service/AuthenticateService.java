package com.qaportal.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qaportal.user.entity.UserLoginEntity;
import com.qaportal.user.jwt.util.JwtUtil;

@Service
public class AuthenticateService {

	@Autowired
	private UserService userService;

	@Autowired
	private JwtUtil jwtUtil;

	public String authenticate(UserLoginEntity userLoginEntity) {

		String login_mail_id = userLoginEntity.getEmailid();
		String login_password = userLoginEntity.getPassword();
		String user_password_in_db = userService.findByemailid(login_mail_id).getPassword();

		if (userService.checkPass(login_password, user_password_in_db)) {
			return jwtUtil.generateToken(userLoginEntity.getEmailid());
		} else {
			return "Invalid Password";
		}
	}

	public String getUsernameFromToken(String token) {

		try {
			String username = jwtUtil.extractUsername(token.substring(7));
			return username;
		} catch (Exception ex) {
			return null;
		}
	}

}

package com.qaportal.answers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AnswersApplicationTest {
	
	@Test
	void contextLoads() {
	}

}

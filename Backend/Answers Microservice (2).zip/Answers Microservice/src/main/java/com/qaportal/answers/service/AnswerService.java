package com.qaportal.answers.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qaportal.answers.entity.AnswerEntity;
import com.qaportal.answers.exception.AnswersNotFoundException;
import com.qaportal.answers.feign.QuestionProxy;
import com.qaportal.answers.feign.UserAuthProxy;
import com.qaportal.answers.repository.AnswersRepository;

@Service
public class AnswerService {

	@Autowired
	private AnswersRepository answersRepository;
	
	@Autowired
	private UserAuthProxy userAuthProxy;
	
	@Autowired
	private QuestionProxy questionProxy;
	
	public List<AnswerEntity> getAllAnswers() {
		return answersRepository.findAll();
	}

	public String getUsernameFromToken(String headertoken) {
		
		try {
			String username = userAuthProxy.getTokenUsername(headertoken);
			return username;
		} catch (Exception e) {
			return null;
		}
		
	}

	public boolean createAnswer(AnswerEntity answerEntity, String username) {
		int userid = userAuthProxy.getUserId(username);
		answerEntity.setUserid(userid);
		int questionid = answerEntity.getQuestionid();
		if (questionProxy.checkIfQuestionExists(questionid)) {
			answersRepository.save(answerEntity);
			return true;
		}
		else {
			return false;
		}
	}

	public List<AnswerEntity> getAnswersByquestionId(int questionid) {
		
		List<AnswerEntity> answerEntities = answersRepository.findbyQuestionid(questionid);
		
		if(answerEntities.size() == 0) {
			throw new AnswersNotFoundException(questionid);
		}
		return answerEntities;
		
	}

	
}
